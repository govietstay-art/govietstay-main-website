@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul 2>&1
color 0A
title GoVietStay - Smart Install Phu Quoc English SEO Cluster 2026-2027

set "SCRIPT_DIR=%~dp0"
set "PAYLOAD=%SCRIPT_DIR%_phuquoc_payload"
set "PROJECT="
set "APPROOT="
set "COMPROOT="
set "LAYOUT="

echo ============================================================
echo   GoVietStay - PHU QUOC ENGLISH SEO CLUSTER 2026-2027
echo   SMART INSTALLER V2
echo ============================================================
echo.
echo This installer only adds/updates the 6 English Phu Quoc SEO
echo routes and the shared phu-quoc-guide component.
echo It does NOT delete existing pages and does NOT touch /ru.
echo.

REM Validate installer payload first.
if not exist "%PAYLOAD%\app\travel\phu-quoc-travel-guide\page.tsx" goto :NO_PAYLOAD
if not exist "%PAYLOAD%\components\phu-quoc-guide\PhuQuocGuidePage.tsx" goto :NO_PAYLOAD

REM Try current script folder.
call :TRY_PROJECT "%SCRIPT_DIR%"
if defined PROJECT goto :FOUND_PROJECT

REM Try current CMD working directory.
call :TRY_PROJECT "%CD%"
if defined PROJECT goto :FOUND_PROJECT

REM Walk upward from installer folder up to 8 levels.
set "CANDIDATE=%SCRIPT_DIR%"
for /L %%N in (1,1,8) do (
  for %%P in ("!CANDIDATE!..") do set "CANDIDATE=%%~fP\"
  call :TRY_PROJECT "!CANDIDATE!"
  if defined PROJECT goto :FOUND_PROJECT
)

REM Walk upward from current working directory up to 8 levels.
set "CANDIDATE=%CD%\"
for /L %%N in (1,1,8) do (
  for %%P in ("!CANDIDATE!..") do set "CANDIDATE=%%~fP\"
  call :TRY_PROJECT "!CANDIDATE!"
  if defined PROJECT goto :FOUND_PROJECT
)

REM If installer is somewhere else (for example Downloads), allow manual path.
color 0E
echo [INFO] Automatic project detection did not find GoVietStay.
echo.
echo You can paste the FULL PATH to the GoVietStay project folder now.
echo Example:
echo   C:\Users\YourName\Desktop\govietstay
echo.
set /P "MANUAL=Project folder path (leave blank to cancel): "
if not defined MANUAL goto :NO_PROJECT
set "MANUAL=%MANUAL:\"=%"
call :TRY_PROJECT "%MANUAL%"
if not defined PROJECT goto :BAD_MANUAL

:FOUND_PROJECT
color 0A
echo.
echo [OK] GoVietStay project detected:
echo   %PROJECT%
echo [OK] Next.js app layout:
echo   %LAYOUT%
echo [OK] Routes will be installed into:
echo   %APPROOT%\travel
echo [OK] Shared component will be installed into:
echo   %COMPROOT%\phu-quoc-guide
echo.

echo Installing files...
echo.

if not exist "%APPROOT%\travel" mkdir "%APPROOT%\travel" >nul 2>&1
if not exist "%COMPROOT%" mkdir "%COMPROOT%" >nul 2>&1

REM Merge ONLY the 6 new route folders.
call :COPY_DIR "phu-quoc-travel-guide"
if errorlevel 1 goto :COPY_ERROR
call :COPY_DIR "phu-quoc-3-islands-vs-4-islands"
if errorlevel 1 goto :COPY_ERROR
call :COPY_DIR "phu-quoc-airport-transfer-private-car"
if errorlevel 1 goto :COPY_ERROR
call :COPY_DIR "phu-quoc-with-family"
if errorlevel 1 goto :COPY_ERROR
call :COPY_DIR "phu-quoc-itinerary-3d2n-4d3n"
if errorlevel 1 goto :COPY_ERROR
call :COPY_DIR "best-time-to-visit-phu-quoc"
if errorlevel 1 goto :COPY_ERROR

xcopy "%PAYLOAD%\components\phu-quoc-guide" "%COMPROOT%\phu-quoc-guide\" /E /I /Y /Q >nul
if errorlevel 1 goto :COPY_ERROR

echo [OK] Files copied successfully.
echo.
echo Verifying installed files...
set "FAIL=0"
call :CHECK "%APPROOT%\travel\phu-quoc-travel-guide\page.tsx" "travel\phu-quoc-travel-guide\page.tsx"
call :CHECK "%APPROOT%\travel\phu-quoc-3-islands-vs-4-islands\page.tsx" "travel\phu-quoc-3-islands-vs-4-islands\page.tsx"
call :CHECK "%APPROOT%\travel\phu-quoc-airport-transfer-private-car\page.tsx" "travel\phu-quoc-airport-transfer-private-car\page.tsx"
call :CHECK "%APPROOT%\travel\phu-quoc-with-family\page.tsx" "travel\phu-quoc-with-family\page.tsx"
call :CHECK "%APPROOT%\travel\phu-quoc-itinerary-3d2n-4d3n\page.tsx" "travel\phu-quoc-itinerary-3d2n-4d3n\page.tsx"
call :CHECK "%APPROOT%\travel\best-time-to-visit-phu-quoc\page.tsx" "travel\best-time-to-visit-phu-quoc\page.tsx"
call :CHECK "%COMPROOT%\phu-quoc-guide\PhuQuocGuidePage.tsx" "components\phu-quoc-guide\PhuQuocGuidePage.tsx"
call :CHECK "%COMPROOT%\phu-quoc-guide\data.ts" "components\phu-quoc-guide\data.ts"
call :CHECK "%COMPROOT%\phu-quoc-guide\phu-quoc-guide.css" "components\phu-quoc-guide\phu-quoc-guide.css"

echo.
if "%FAIL%"=="1" goto :VERIFY_ERROR

echo ============================================================
echo   INSTALL COMPLETE
echo ============================================================
echo.
echo New routes:
echo   /travel/phu-quoc-travel-guide
echo   /travel/phu-quoc-3-islands-vs-4-islands
echo   /travel/phu-quoc-airport-transfer-private-car
echo   /travel/phu-quoc-with-family
echo   /travel/phu-quoc-itinerary-3d2n-4d3n
echo   /travel/best-time-to-visit-phu-quoc
echo.
echo Existing /tours/phu-quoc and /ru pages were not deleted.
echo.
echo NEXT STEP:
echo   Open a terminal in this project and run: npm run build
echo.
pause
exit /b 0

:TRY_PROJECT
set "TRY=%~1"
if not defined TRY exit /b 0
for %%P in ("%TRY%") do set "TRY=%%~fP\"
if not exist "!TRY!package.json" exit /b 0

REM Prefer the layout that already contains the existing Phu Quoc tour route.
if exist "!TRY!src\app\tours\phu-quoc\" (
  set "PROJECT=!TRY!"
  set "APPROOT=!TRY!src\app"
  set "COMPROOT=!TRY!src\components"
  set "LAYOUT=src\app"
  exit /b 0
)
if exist "!TRY!app\tours\phu-quoc\" (
  set "PROJECT=!TRY!"
  set "APPROOT=!TRY!app"
  set "COMPROOT=!TRY!components"
  set "LAYOUT=app"
  exit /b 0
)

REM Otherwise accept whichever App Router layout exists.
if exist "!TRY!src\app\" (
  set "PROJECT=!TRY!"
  set "APPROOT=!TRY!src\app"
  set "COMPROOT=!TRY!src\components"
  set "LAYOUT=src\app"
  exit /b 0
)
if exist "!TRY!app\" (
  set "PROJECT=!TRY!"
  set "APPROOT=!TRY!app"
  set "COMPROOT=!TRY!components"
  set "LAYOUT=app"
  exit /b 0
)
exit /b 0

:COPY_DIR
set "SLUG=%~1"
xcopy "%PAYLOAD%\app\travel\%SLUG%" "%APPROOT%\travel\%SLUG%\" /E /I /Y /Q >nul
exit /b %errorlevel%

:CHECK
if exist "%~1" (
  echo   [OK] %~2
) else (
  echo   [MISSING] %~2
  set "FAIL=1"
)
exit /b 0

:BAD_MANUAL
color 0C
echo.
echo [STOP] That folder is not a compatible GoVietStay Next.js project.
echo It must contain package.json and either app\ or src\app\.
echo.
echo Nothing was copied.
pause
exit /b 2

:NO_PROJECT
color 0C
echo.
echo [STOP] GoVietStay project root was not found.
echo.
echo The project root must contain:
echo   package.json
echo and EITHER:
echo   app\
echo or:
echo   src\app\
echo.
echo Nothing was copied.
pause
exit /b 2

:NO_PAYLOAD
color 0C
echo [STOP] Installer payload is missing or incomplete.
echo Keep INSTALL_PHU_QUOC_EN.bat and _phuquoc_payload together.
echo Nothing was copied.
pause
exit /b 3

:COPY_ERROR
color 0C
echo.
echo [ERROR] Windows could not copy one or more files.
echo Check folder permissions and try again.
echo Nothing outside this Phu Quoc cluster is deleted by this installer.
pause
exit /b 4

:VERIFY_ERROR
color 0E
echo.
echo [WARNING] Copy finished but one or more expected files are missing.
echo Please send this screen to ChatGPT before deploying.
pause
exit /b 5
