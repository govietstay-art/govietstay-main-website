# GoVietStay Phu Quoc English SEO Cluster 2026-2027 — Smart Installer V2

The installer supports both common Next.js App Router layouts:

- `app/...` + `components/...`
- `src/app/...` + `src/components/...`

It first tries to locate the project automatically from the installer directory and current working directory, walking upward up to eight levels. If it still cannot locate the project, it asks for the full project path.

The project is accepted only when `package.json` exists and either `app/` or `src/app/` exists. When both layouts are present, the installer prefers the one that already contains the existing `tours/phu-quoc` route.

## Installed routes

- `/travel/phu-quoc-travel-guide`
- `/travel/phu-quoc-3-islands-vs-4-islands`
- `/travel/phu-quoc-airport-transfer-private-car`
- `/travel/phu-quoc-with-family`
- `/travel/phu-quoc-itinerary-3d2n-4d3n`
- `/travel/best-time-to-visit-phu-quoc`

## Safety

The installer only merges the six route folders above and the `phu-quoc-guide` shared component. It does not delete existing pages and does not intentionally modify `/ru` or `/tours/phu-quoc`.

After `INSTALL COMPLETE`, run `npm run build` from the detected GoVietStay project root.
